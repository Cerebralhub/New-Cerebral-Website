# Cerebral Hub — website redesign

A hand-built, dependency-free static site: plain HTML, CSS and JavaScript. No build step, no
framework. Open `index.html` in a browser or drop the whole folder on any host.

## Structure

```
index.html          Home    — hero + showreel, process, client marquee, why choose, CTA
about.html          About   — mission, stats, trusted-by, FAQ accordion
services.html       Services— four services, process recap
work.html           Work    — nine case studies linking to the existing PDFs
contact.html        Contact — enquiry form, offices, socials

assets/css/styles.css      One stylesheet. Section 1 holds every design token.
assets/js/main.js          Sticky header, mobile nav, scroll reveals, counters,
                           FAQ accordion, marquee loop, form handling.
assets/img/logo.svg        Cerebral Hub mark, dark wordmark (for light backgrounds)
assets/img/logo-light.svg  Cerebral Hub mark, white wordmark (used in the header/footer)
assets/img/illustrations/  13 original SVG illustrations, all hand-coded in the brand palette
```

## Design system

Everything visual is controlled by the custom properties at the top of `styles.css`:

| Token | Value | Used for |
| --- | --- | --- |
| `--ink` / `--ink-2` / `--ink-3` | `#0A0B0F` `#101219` `#171A23` | dark surfaces |
| `--cream` | `#F6F4EF` | light section background |
| `--accent` | `#F58A07` | primary CTA, eyebrows, highlights |
| `--blue` `--green` `--red` `--gold` | logo colours | illustration accents |
| `--font-display` | Space Grotesk | headings |
| `--font-body` | Inter | body copy |

Change the accent in one place and it propagates across every page.

## Content

All copy is carried over verbatim from the current site — headings, service descriptions,
process steps, FAQ answers, addresses and phone number. The homepage showreel is the same
YouTube embed (`91wWCkmO5H0`).

## Photographic assets

The client logos and case-study artwork are referenced from `https://cerebralhub.com/assets/...`
because those binaries could not be downloaded into this build. Once you deploy to the same
domain they resolve as-is; if you'd rather keep them local, copy the files into
`assets/img/clients/` and `assets/img/work/` and swap the absolute URLs for relative ones.

The case-study "More" links point at the existing PDFs under `/pdfs/`.

## Wiring the forms

`assets/js/main.js` currently intercepts both the contact form and the newsletter form and shows
a confirmation. Replace the handler in the *Forms* block with a `fetch()` to your endpoint
(Formspree, Netlify Forms, or your own API) when you go live.

## Accessibility & performance

- Skip link, visible focus rings, `aria-current` on the active nav item, labelled form fields.
- The FAQ uses real buttons with `aria-expanded`; the mobile drawer closes on `Esc`.
- All animation is disabled under `prefers-reduced-motion`.
- A `<noscript>` block keeps every section visible if JavaScript fails.
- Illustrations are SVG, so the whole design layer weighs a few kilobytes.
